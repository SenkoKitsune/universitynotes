Steady state solutions
	$\displaystyle\frac{dy}{dt} = 0$

[[MATH 101 Lecture 07]]