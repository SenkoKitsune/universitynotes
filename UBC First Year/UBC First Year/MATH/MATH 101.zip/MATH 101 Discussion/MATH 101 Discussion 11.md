$Pr$ is a function that takes a subset of the sample space and assigns it a number in $[0,1]$

Probability mass function (PMT)
	$f(x) = Pr(R=x)$
		$\displaystyle\sum_{x=1}^{n}f(x) = 1$
			Where $n$ is the # of possibilities
			