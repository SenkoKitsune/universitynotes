$erf(x) = \displaystyle\frac{2}{\displaystyle\sqrt{π}}\displaystyle\int_{0}^{x}e^{-t^2}dt$


[[MATH 101 Lecture 03]]