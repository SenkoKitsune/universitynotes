$\displaystyle\int_{a}^{b}f(x)dx = \displaystyle\int_{a}^{c}f(x)dx + \displaystyle\int_{c}^{b}f(x)dx$


$\displaystyle\int_{a}^{b}f(x)dx$ = -$\displaystyle\int_{b}^{a}f(x)dx$


$\displaystyle\int_{a}^{b}cf(x)dx = c\displaystyle\int_{a}^{b}f(x)dx$

[[MATH 101 Lecture 02]]