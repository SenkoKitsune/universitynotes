Partial fractions
eg) Compete $\displaystyle\int sec(x)dx$
1) Rewrite sec(x) = $\displaystyle\frac{cos(x)}{cos{x}^2}$
2) u = sin(x)
3) Use partial fractions to compute $\displaystyle\int \displaystyle\frac{1}{1-u^2}du$
4) Compute $\displaystyle\int sec(x)dx$

Can split complicated rational functions into easier parts that we know how to integrate

[[MATH 101 Lecture 04]]